import { NextRequest, NextResponse } from 'next/server';
import { SignJWT } from 'jose';

export const runtime = 'nodejs';
export const maxDuration = 60;

type TelegramUpdate = {
  update_id?: number;
  message?: {
    message_id?: number;
    text?: string;
    chat: { id: number; type?: string };
    from?: { id: number; first_name?: string };
  };
};

type TelegramApiResult = { ok?: boolean };

async function callTelegram(method: string, payload: Record<string, unknown>) {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) throw new Error('Telegram bot is not configured');

  const response = await fetch(`https://api.telegram.org/bot${token}/${method}`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(payload),
    cache: 'no-store',
    signal: AbortSignal.timeout(8000)
  });

  const result = (await response.json()) as TelegramApiResult;
  if (!response.ok || result.ok !== true) {
    throw new Error(`Telegram method failed: ${method}`);
  }
  return result;
}

async function sendText(chatId: number, text: string) {
  const characters = Array.from(text || 'ORACLE не вернул ответ.');
  while (characters.length) {
    const chunk = characters.splice(0, 3800).join('');
    await callTelegram('sendMessage', { chat_id: chatId, text: chunk });
  }
}

async function createOwnerSession() {
  const userId = process.env.GENESIS_TELEGRAM_OWNER_USER_ID;
  const authSecret = process.env.AUTH_SECRET;
  if (!userId || !authSecret || authSecret.length < 32) {
    throw new Error('Telegram owner session is not configured');
  }

  return new SignJWT({ sub: userId })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime('7d')
    .sign(new TextEncoder().encode(authSecret));
}

async function askOracle(
  req: NextRequest,
  chatId: number,
  message: string,
  requestId: string
) {
  const appOrigin =
    process.env.GENESIS_APP_ORIGIN ||
    process.env.APP_URL ||
    req.nextUrl.origin;
  const origin = new URL(appOrigin);

  if (origin.protocol !== 'https:') {
    throw new Error('GENESIS application origin must use HTTPS');
  }

  const session = await createOwnerSession();
  await callTelegram('sendChatAction', { chat_id: chatId, action: 'typing' });

  const response = await fetch(new URL('/api/chat', origin), {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      origin: origin.origin,
      cookie: `genesis_session=${session}`,
      'x-idempotency-key': requestId
    },
    body: JSON.stringify({ message, requestId }),
    cache: 'no-store',
    signal: AbortSignal.timeout(55000)
  });

  const result = (await response.json().catch(() => ({}))) as {
    answer?: unknown;
    error?: unknown;
  };

  if (!response.ok || typeof result.answer !== 'string') {
    throw new Error(
      typeof result.error === 'string'
        ? result.error
        : `ORACLE request failed with status ${response.status}`
    );
  }

  await sendText(chatId, result.answer);
}

export async function POST(req: NextRequest) {
  const secret = process.env.TELEGRAM_WEBHOOK_SECRET;
  if (
    !secret ||
    req.headers.get('x-telegram-bot-api-secret-token') !== secret
  ) {
    return NextResponse.json({ ok: false }, { status: 401 });
  }

  try {
    const update = (await req.json()) as TelegramUpdate;
    const message = update.message;
    if (!message?.chat?.id || !message.from?.id) {
      return NextResponse.json({ ok: true });
    }

    const allowedUserId = process.env.GENESIS_TELEGRAM_ALLOWED_USER_ID;
    const chatId = message.chat.id;
    const senderId = message.from.id;

    if (
      !allowedUserId ||
      String(senderId) !== allowedUserId ||
      message.chat.type !== 'private' ||
      chatId !== senderId
    ) {
      await sendText(
        chatId,
        'Этот экземпляр GENESIS работает в приватном режиме. Доступ не предоставлен.'
      );
      return NextResponse.json({ ok: true });
    }

    const text = (message.text || '').trim();

    if (text.startsWith('/start') || text.startsWith('/open')) {
      const app = process.env.TELEGRAM_WEBAPP_URL;
      if (!app || !app.startsWith('https://')) {
        await sendText(
          chatId,
          'Mini App пока не подключён. Нужен публичный HTTPS-адрес приложения.'
        );
      } else {
        await callTelegram('sendMessage', {
          chat_id: chatId,
          text: 'GENESIS готов. Открой личное пространство или напиши ORACLE прямо здесь.',
          reply_markup: {
            inline_keyboard: [[
              { text: 'Открыть GENESIS', web_app: { url: app } }
            ]]
          }
        });
      }
      return NextResponse.json({ ok: true });
    }

    if (text.startsWith('/help')) {
      await sendText(
        chatId,
        'Команды GENESIS:\n/start — открыть пространство\n/open — открыть Mini App\n/help — помощь\n\nПросто отправь сообщение, чтобы поговорить с ORACLE.'
      );
      return NextResponse.json({ ok: true });
    }

    if (!text) {
      await sendText(chatId, 'Пока ORACLE принимает только текстовые сообщения.');
      return NextResponse.json({ ok: true });
    }

    if (text.length > 12000) {
      await sendText(
        chatId,
        'Сообщение слишком длинное. Отправь его несколькими частями.'
      );
      return NextResponse.json({ ok: true });
    }

    const requestId = `telegram-${update.update_id ?? `${chatId}-${message.message_id ?? Date.now()}`}`;

    try {
      await askOracle(req, chatId, text, requestId);
    } catch (error) {
      console.error(
        'GENESIS Telegram ORACLE error',
        error instanceof Error ? error.message : 'UNKNOWN_ERROR'
      );
      await sendText(
        chatId,
        'Не удалось получить ответ ORACLE. Попробуй отправить сообщение ещё раз через минуту.'
      );
    }

    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error(
      'GENESIS Telegram webhook error',
      error instanceof Error ? error.message : 'UNKNOWN_ERROR'
    );
    return NextResponse.json({ ok: false }, { status: 500 });
  }
}
