# GENESIS 5.0 — Recovery workspace status

Дата проверки: 4 ноября 2026 года  
Статус: **RECOVERY / PREVIEW BUILD — НЕ PRODUCTION RELEASE**

## 1. Исходная база и сохранность

- Контрольная точка `main`: `e7b82a92a0743157e69f358a50fed193cf5cea14`.
- Работа ведётся в отдельной локальной ветке `genesis/5.0-integration` в изолированной Vercel Sandbox.
- Ранее сохранённая работа `genesis/telegram-oracle-chat` (`a88b454`) перенесена поверх актуального `main`; конфликт Telegram webhook разрешён вручную.
- `main` не изменялся. Production deployment не обновлялся.
- Оригинальные ZIP-архивы сохранены; Future Interface применён к копии серверного исходника.

## 2. Интегрировано

- Future Interface: графитово-серебряная визуальная система.
- Новый адаптивный `ManualOracle`.
- Ручной ChatGPT workflow без автоматических платных AI API-вызовов: GENESIS хранит диалог, пользователь сам копирует запрос в ChatGPT и сохраняет ответ обратно.
- Поиск по истории, подсказки, копирование сообщений и сохранение в `Conversation` / `ChatMessage`.
- Новый `/api/manual-chat`: same-origin, авторизованная сессия, проверка владения диалогом, транзакционное сохранение и audit event.
- Сохранена Telegram ORACLE-интеграция из рабочей ветки.
- Регистрация дополнительно защищена same-origin проверкой. Telegram webhook отдельно проверяет секретный заголовок Telegram; это серверный callback, поэтому он не использует browser Origin как механизм аутентификации.
- Исправлены пути PWA contract tests под фактическую структуру `site/`.

## 3. Зависимости и безопасность

Обновлены совместимые версии:
- Next.js `15.5.29`.
- Prisma / Prisma Client `6.19.3`.
- OpenAI SDK `7.50.0`.
- Zod `4.6.7`.
- PostCSS принудительно закреплён на `8.5.32` через npm override.

`npm audit` после обновлений сообщает **3 high** и **0 critical / 0 moderate / 0 low**. Оставшиеся high относятся к цепочке Prisma 6 (`prisma`, `@prisma/config`, `deepmerge-ts`); доступное исправление требует major migration на Prisma 7. Принудительный major upgrade не выполнялся, чтобы не ломать текущую схему и database adapter без отдельной миграции.

В Vercel project ключ `GENESIS_BOOTSTRAP_TOKEN` существует только для Production. Секретные Telegram/Auth/AI переменные также имеют production scope. Preview/Development deployment не получит их автоматически. Значения секретов в этот пакет не включены.

## 4. Проверки

| Проверка | Результат |
|---|---:|
| Prisma schema validation | PASS (с placeholder `DATABASE_URL`; реальная БД не подключалась) |
| TypeScript `tsc --noEmit` | PASS |
| Next.js production build | PASS |
| PWA `storage.js` / `sw.js` syntax | PASS |
| PWA ORACLE + Decision Lab contract tests | 8/8 PASS |
| Manual Chat + request-origin contract tests | 4/4 PASS |
| Server test suite | 148/162 PASS; 14 FAIL |

### Оставшиеся 14 server test failures

Они не скрыты и не отключены. Текущие проверки указывают на несоответствия/недостающую реализацию в следующих областях:
- последовательное исполнение ORACLE specialist plan;
- Artifact lifecycle schema / relations / version metadata;
- атомарное сохранение user message и chat idempotency;
- Execution / Decision domain relations;
- Goal relations с Worlds / Projects / Actions / Life Timeline;
- Import Preview receipt: raw payload hash, streaming byte limit и nonce;
- LifeEvent и immutable LifeEventVersion;
- Memory provenance / immutable history;
- явно выбранный Ollama provider;
- durable rate-limit contract;
- Context Inspector UI.

Это реальные release blockers до публичного production-релиза. Часть проверок может требовать обновления устаревших контрактов, но тесты не отключались ради зелёного статуса.

## 5. Что ещё не подтверждено

- Миграции не применялись к реальному PostgreSQL/pgvector.
- Не проверялись конкурентные транзакции, restore drill и multi-device sync.
- Не выполнен iPhone Safari / Telegram Mini App E2E.
- Telegram webhook не проверялся с реальным ботом и живыми Telegram credentials.
- Не подтверждён production ORACLE request с реальным provider key.
- Никакой production deployment не выполнялся.

## 6. Release gate

Перед публичным релизом требуется закрыть 14 server test failures, провести Prisma migration plan, проверить реальные PostgreSQL migrations, восстановление резервной копии и Telegram E2E. Текущий пакет — интегрированная recovery-сборка для проверки и дальнейшей разработки, а не заявление о production readiness.
