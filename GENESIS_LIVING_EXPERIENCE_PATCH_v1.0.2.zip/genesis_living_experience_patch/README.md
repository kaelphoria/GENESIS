# GENESIS Living Experience — patch v1.0.1

Цель: mobile-first UX-переработка существующего Dashboard без удаления модулей и данных.

## Применение
1. Распаковать архив в корень клона `kaelphoria/GENESIS` на ветке `genesis-5-recovery`.
2. Выполнить `python3 genesis_living_experience_patch/apply_patch.py`.
3. Перейти в каталог приложения `telegram-integration/GENESIS_4.0_FINAL/source/server`.
4. Установить зависимости при необходимости и выполнить `npm run typecheck`, `npm test`, `npm run build`.
5. Проверить мобильную навигацию, меню «Ещё», добавление действия, Telegram BackButton и reduced-motion.

Скрипт создаёт резервные копии двух изменяемых файлов с суффиксом `.genesis-backup`. Он проверяет ожидаемые исходные фрагменты и прекращает работу, если структура исходников отличается.

Патч не выполняет push, не создаёт deployment и не меняет Production.
