GENESIS — EVENT HORIZON 2.1 PATCH

Apply from the repository root and preserve directory paths. This is a focused patch containing the four changed application files and this readme. It excludes secrets, environment files, node_modules, build output, and package-lock.json.

After extraction, run npm install from telegram-integration/GENESIS_4.0_FINAL/source/server to refresh package-lock.json for the added Three.js dependency, then run npm run check and npm run build.

Validated in Vercel Sandbox: TypeScript check passed; 167/167 tests passed; Next.js production build completed and generated all 31 static pages; git diff --check passed.

Not deployed to GitHub or Vercel Preview by packaging alone. main and Production were not changed.
