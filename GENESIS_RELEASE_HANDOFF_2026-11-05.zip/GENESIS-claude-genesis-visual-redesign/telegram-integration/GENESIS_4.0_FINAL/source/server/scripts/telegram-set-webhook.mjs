const token = process.env.TELEGRAM_BOT_TOKEN;
const secret = process.env.TELEGRAM_WEBHOOK_SECRET;
const appUrl = process.env.APP_URL;

if (!token || !secret || !appUrl?.startsWith('https://')) {
  console.error('Set TELEGRAM_BOT_TOKEN, TELEGRAM_WEBHOOK_SECRET and HTTPS APP_URL.');
  process.exit(1);
}

async function telegram(method, payload) {
  const response = await fetch(`https://api.telegram.org/bot${token}/${method}`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(payload),
  });
  let result;
  try {
    result = await response.json();
  } catch {
    throw new Error(`${method} returned a non-JSON response (HTTP ${response.status}).`);
  }
  if (!response.ok || result.ok !== true) {
    throw new Error(`${method} failed: ${result.description || `HTTP ${response.status}`}`);
  }
  return result;
}

const origin = appUrl.replace(/\/$/, '');

try {
  await telegram('setWebhook', {
    url: `${origin}/api/telegram/webhook`,
    secret_token: secret,
    allowed_updates: ['message'],
  });
  console.log('Telegram webhook registered.');

  await telegram('setMyCommands', {
    commands: [
      { command: 'start', description: 'Открыть GENESIS' },
      { command: 'open', description: 'Открыть Mini App' },
      { command: 'help', description: 'Помощь' },
    ],
  });
  await telegram('setChatMenuButton', {
    menu_button: {
      type: 'web_app',
      text: 'GENESIS',
      web_app: { url: `${origin}/telegram` },
    },
  });
  console.log('Telegram commands and Mini App menu button configured.');
} catch (error) {
  console.error(error instanceof Error ? error.message : 'Telegram configuration failed.');
  process.exitCode = 1;
}
