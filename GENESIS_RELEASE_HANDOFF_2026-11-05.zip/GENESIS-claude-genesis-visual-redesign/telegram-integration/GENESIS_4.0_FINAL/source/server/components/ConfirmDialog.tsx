'use client';
import {useCallback,useEffect,useRef,useState,type ReactNode} from 'react';

export type ConfirmOptions={message:string;title?:string;confirmLabel?:string;phrase?:string;danger?:boolean};
type Pending=ConfirmOptions&{resolve:(ok:boolean)=>void};

/** Замена window.confirm/prompt: промис-диалог в стиле GENESIS. phrase — слово, которое нужно ввести. */
export function useConfirm():[(options:ConfirmOptions)=>Promise<boolean>,ReactNode]{
  const [pending,setPending]=useState<Pending|null>(null);
  const [typed,setTyped]=useState('');
  const dialogRef=useRef<HTMLDivElement>(null);
  const previousFocusRef=useRef<HTMLElement|null>(null);
  const ask=useCallback((options:ConfirmOptions)=>new Promise<boolean>(resolve=>{setTyped('');setPending({...options,resolve})}),[]);
  const finish=useCallback((ok:boolean)=>{setPending(current=>{current?.resolve(ok);return null})},[]);
  useEffect(()=>{
    if(!pending)return;
    previousFocusRef.current=document.activeElement instanceof HTMLElement?document.activeElement:null;
    const focusable=()=>Array.from(dialogRef.current?.querySelectorAll<HTMLElement>('button:not([disabled]),input:not([disabled]),[href],select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])')||[]).filter(el=>!el.hasAttribute('hidden'));
    const first=focusable()[0];
    (first||dialogRef.current)?.focus();
    const onKey=(event:KeyboardEvent)=>{
      if(event.key==='Escape'){event.preventDefault();finish(false);return;}
      if(event.key!=='Tab')return;
      const items=focusable();
      if(!items.length){event.preventDefault();dialogRef.current?.focus();return;}
      const firstItem=items[0],lastItem=items[items.length-1];
      if(event.shiftKey&&document.activeElement===firstItem){event.preventDefault();lastItem.focus();}
      else if(!event.shiftKey&&document.activeElement===lastItem){event.preventDefault();firstItem.focus();}
    };
    window.addEventListener('keydown',onKey);
    return()=>{window.removeEventListener('keydown',onKey);previousFocusRef.current?.focus();previousFocusRef.current=null;};
  },[pending,finish]);
  const allowed=!pending?.phrase||typed===pending.phrase;
  const node=pending?(
    <div className="modal-backdrop" onMouseDown={event=>{if(event.target===event.currentTarget)finish(false)}}>
      <div ref={dialogRef} tabIndex={-1} className="modal gx-confirm" role="alertdialog" aria-modal="true" aria-label={pending.title||'Подтверждение'}>
        <div className="eyebrow">GENESIS / ПОДТВЕРЖДЕНИЕ</div>
        <h2>{pending.title||'Вы уверены?'}</h2>
        <p className="gx-confirm-text">{pending.message}</p>
        {pending.phrase&&<label className="gx-confirm-field">Введи <b>{pending.phrase}</b> для подтверждения<input autoFocus autoComplete="off" autoCapitalize="characters" value={typed} onChange={event=>setTyped(event.target.value)}/></label>}
        <div className="gx-confirm-actions">
          <button type="button" className="text-btn" onClick={()=>finish(false)}>Отмена</button>
          <button type="button" className={pending.danger?'danger-btn':'primary-btn compact'} disabled={!allowed} onClick={()=>finish(true)}>{pending.confirmLabel||'Подтвердить'}</button>
        </div>
      </div>
    </div>
  ):null;
  return [ask,node];
}
