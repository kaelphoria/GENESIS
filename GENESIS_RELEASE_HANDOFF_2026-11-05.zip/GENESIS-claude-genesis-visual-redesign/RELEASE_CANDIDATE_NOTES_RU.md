# GENESIS — Release Candidate (2026-11-05)

Это обновлённая исходная копия проекта. Она **не развёрнута в Production** и не должна считаться окончательно сертифицированным релизом до успешного `npm ci`, `npm run check`, `npm run build`, миграции на отдельной БД и проверки Telegram Mini App на реальном устройстве.

## Что изменено

- `telegram-integration/GENESIS_4.0_FINAL/source/server/components/Dashboard.tsx`: Telegram WebApp SDK инициализируется один раз при монтировании Dashboard. Обработчик BackButton подключается отдельно и обновляется при смене вкладки; cleanup снимает только собственный обработчик.
- `components/ConfirmDialog.tsx`: добавлен focus trap для Tab/Shift+Tab, начальный фокус и возврат фокуса на исходный элемент после закрытия.
- `scripts/telegram-set-webhook.mjs`: все три Telegram API-вызова проверяют HTTP-статус и `ok: true`; ошибка настройки команд или кнопки меню теперь возвращает ненулевой exit code.
- Добавлены регрессионные тесты для этих изменений.

## Проверки, выполненные в среде подготовки

- `npm test`: **170/170 passed**.
- `node --check` для всех `.mjs`-файлов сервера: passed.
- JSON parse для JSON-файлов сервера: passed.
- `npm ci --no-audit --no-fund`: не завершился в доступное время из-за недоступности/задержки получения пакетов.
- `npm ci --offline`: остановился, потому что пакет `zod@4.6.7` отсутствует в локальном npm cache.
- `npm run typecheck`: не прошёл, поскольку после незавершённой установки отсутствуют полноценные `@types/*`; это не является подтверждённой ошибкой исходников.
- `npm run build`: не запускался, так как зависимости не установлены полностью.

## Vercel — настройки проекта

Для этого исходного дерева задайте:

- **Root Directory:** `telegram-integration/GENESIS_4.0_FINAL/source/server`
- **Install Command:** `npm ci`
- **Build Command:** `npm run build`
- **Output Directory:** оставить автоматически определяемым Next.js.

Удалите из Vercel Install Command любые команды, которые распаковывают `GENESIS_LIVING_EXPERIENCE_PATCH_v1.0.2.zip` и запускают `apply_patch.py`. Этот внешний патч устарел и завершался сообщением `Не найден JSX навигации`; он не должен выполняться при каждой установке зависимостей.

Не меняйте Production target/alias до отдельного разрешения владельца. Сначала создайте Preview deployment.

## Переменные окружения

Задайте в Preview/Production Environment Variables (значения секретов генерируйте отдельно, не копируйте из документации):

- `DATABASE_URL` — PostgreSQL connection string с TLS, например `...?sslmode=require`.
- `AUTH_SECRET` — случайная строка не короче 32 символов.
- `GENESIS_BOOTSTRAP_TOKEN` — отдельный случайный токен не короче 32 символов для первичной регистрации владельца; после создания владельца удалите его из окружения.
- `APP_URL` — канонический HTTPS URL приложения.
- `GENESIS_APP_ORIGIN` — тот же origin без пути, например `https://genesis.example.com`.
- `TELEGRAM_BOT_TOKEN`, `TELEGRAM_WEBHOOK_SECRET` — если включается Telegram.
- `TELEGRAM_WEBAPP_URL` — полный HTTPS URL Mini App, заканчивающийся на `/telegram`.
- `GENESIS_TELEGRAM_ALLOWED_USER_ID` — Telegram numeric user ID, которому разрешён вход.
- `GENESIS_TELEGRAM_OWNER_USER_ID` — внутренний ID существующего владельца GENESIS, а не Telegram numeric ID.

ORACLE по умолчанию использует OpenAI provider. Если `OPENAI_API_KEY` не задан, API-завершения ORACLE недоступны; ручной режим передачи запроса в ChatGPT остаётся отдельным сценарием. Для self-hosted установки можно явно выбрать `GENESIS_AI_PROVIDER=ollama` и настроить `OLLAMA_BASE_URL`, `OLLAMA_MODEL` и совместимую embedding-модель. Не указывайте Ollama на публичный незашифрованный endpoint.

## Порядок выпуска

1. Создать отдельную PostgreSQL БД для Preview и настроить переменные Preview.
2. В корне сервера выполнить `npm ci`.
3. Выполнить `npm run db:generate`.
4. Выполнить `npm run check` и `npm run build`.
5. На выделенной БД выполнить `npm run db:migrate` (или `npx prisma migrate deploy`). Не запускать миграции на Production до резервной копии и отдельного разрешения.
6. Развернуть Preview и проверить регистрацию/вход, загрузку Dashboard, все 11 разделов, создание/изменение/удаление записей, экспорт, мобильную ширину 360/390/430 px и desktop 1280 px.
7. Настроить Telegram webhook командой `npm run telegram:set-webhook` после заполнения переменных; проверить Mini App в официальном Telegram-клиенте.
8. Только после проверки Preview и backup/restore — отдельное решение о Production.

## Ограничения этой поставки

В текущей среде не удалось установить полный набор npm-зависимостей. Поэтому этот архив — **проверенный тестами Release Candidate**, но не полностью собранный и не опубликованный Production release. Внешние секреты, реальная БД, Telegram bot token и Vercel project settings не входят в архив и не были изменены.
