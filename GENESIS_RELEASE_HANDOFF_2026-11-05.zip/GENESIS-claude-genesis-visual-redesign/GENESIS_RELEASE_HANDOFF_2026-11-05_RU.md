# GENESIS — Release handoff (2026-11-05)

## Текущий статус

Поставка содержит локальные исправления Release Candidate, но изменения ещё не опубликованы в GitHub. Production не затронут.

### Проверено локально на архиве Release Candidate

- `npm test`: 170/170 тестов пройдены.
- Проверки синтаксиса `.mjs` и JSON: пройдены.
- `npm ci`: не завершился в среде подготовки из-за недоступности npm registry; пакет `zod@4.6.7` отсутствует в локальном npm cache.
- Поэтому локальные `typecheck` и `next build` не подтверждены.

### Проверено на Vercel

- Предыдущий Preview deployment исходного commit `f9929b108d4ff057709c5c035f00b9a922c822c6` имел статус `READY`.
- Его логи подтверждают `npm ci`, 167/167 тестов, успешную компиляцию Next.js 15.5.29, проверку типов и production build; страницы были собраны.
- После настройки Preview-only environment variables создан новый Preview redeploy `dpl_HyHZVW1N2XYyJ7GjySS197niwNZc` (`genesis-ijykq69z0-armikaelar-5591.vercel.app`). Новый Preview redeploy завершился со статусом `READY`; логи подтверждают `npm ci`, `Build Completed in /vercel/output` и `Deployment completed`. Для исходного commit в предыдущем полном build-логе зафиксировано 167/167 тестов, успешная проверка типов и Next.js build.
- Preview защищён Vercel SSO. Защиту не отключали.

### База данных и секреты Preview

Для Preview-ветки `claude/genesis-visual-redesign` настроены отдельные секретные переменные:

- `DATABASE_URL` — отдельная ветка Neon `genesis-preview-2026-11-04`, не production-ветка.
- `AUTH_SECRET` — новый случайный Preview-only секрет.
- `GENESIS_TELEGRAM_OWNER_USER_ID` — привязка к существующей записи владельца в Preview БД.
- `TELEGRAM_WEBHOOK_SECRET` — новый Preview-only секрет.

У Preview-ветки Neon проверено: 13 завершённых Prisma migrations, 1 запись владельца, 9 миров. Число миграций совпадает с 13 каталогами миграций в поставленном исходном коде. Содержимое пользовательских записей не выгружалось.

### Что ещё необходимо для Telegram Bot

В Preview не обнаружены (переменные отсутствуют в перечне branch-scoped Preview env):

- `TELEGRAM_BOT_TOKEN` — токен существующего бота из BotFather.
- `GENESIS_TELEGRAM_ALLOWED_USER_ID` — числовой Telegram ID владельца.

Без этих двух значений нельзя безопасно завершить настройку webhook и разрешённого доступа. Их нужно добавить в Vercel Preview Environment Variables для ветки `claude/genesis-visual-redesign`, затем redeploy и выполнить `npm run telegram:set-webhook`. Токены не следует помещать в исходники или ZIP.

### Блокировка публикации локальных исправлений

GitHub repository metadata сообщает, что у владельца есть push-доступ, но GitHub integration отклоняет Git write API с `403 Resource not accessible by integration`, включая `create_blob`. Поэтому локальные исправления не удалось записать в ветку `claude/genesis-visual-redesign` и автоматически развернуть из GitHub.

После восстановления GitHub Contents / Git Data write permissions для интеграции нужно отправить изменения только в `claude/genesis-visual-redesign`, дождаться нового Preview build и проверить приложение. `main` и Production не менять.

## Безопасные границы

- Не запускать миграции на Production.
- Не переключать Production alias.
- Не отключать Vercel SSO для Preview.
- Не добавлять реальные секреты в репозиторий, документы или ZIP.
- Не запускать `npm audit fix --force`: это может внести несовместимые major-обновления.
